docker build -t nodejs1 .

docker login

docker tag nodejs1 cachua0707/nodejs1:v1

docker push cachua0707/nodejs1:v1






docker build -t node .

docker tag node cachua0707/node:v1

docker push cachua0707/node:v1



docker build -t mariadb .

docker tag mariadb cachua0707/mariadb:v1

docker push cachua0707/mariadb:v1